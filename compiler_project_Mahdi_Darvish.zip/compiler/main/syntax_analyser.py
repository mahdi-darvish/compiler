import sys
from lexical_analyser import *


class Syntax:
    def __init__(self, lexical_analyser):
        self.lexical_analyser = lexical_analyser

        self.symbols = set()
        self.labels = set()
        self.current_token = None
        self.peekToken = None
        self.next_token()
        self.next_token()
        self.line_counter = 1

    def check_token(self, kind):
        return kind == self.current_token.kind

    def checkPeek(self, kind):
        return kind == self.peekToken.kind

    def match(self, kind):
        if not self.check_token(kind):
            self.abort("Expected " + kind + ", got " + self.current_token.kind)
        print('matched: ', kind)
        self.next_token()

    def next_token(self):
        self.current_token = self.peekToken
        self.peekToken = self.lexical_analyser.getToken()

    def comparison_operator(self):
        return self.check_token('greater_than') or \
               self.check_token('equality') or \
               self.check_token('less_than')


    def abort(self, message):
        sys.exit("Error at line {}. ".format(self.line_counter) + message)


    def start(self):
        print("start")

        self.new_line()

        while not self.check_token('end_of_file'):
            self.statement()

    def statement(self):

        if self.check_token('if'):
            print("STATEMENT --> IF")
            self.next_token()
            self.match('open_parenthesis')
            self.comparison()

            self.match('close_parenthesis')
            self.match('colon')
            self.match('open_curly_bracket')

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')

        elif self.check_token('while'):
            print("STATEMENT --> WHILE")
            self.next_token()
            self.match('open_parenthesis')
            self.comparison()

            self.match('close_parenthesis')
            self.match('colon')
            self.match('open_curly_bracket')
            self.new_line()

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')


        elif self.check_token('for'):
            print("STATEMENT --> FOR")
            self.next_token()
            self.match('open_parenthesis')
            self.match('identifier')
            self.match('assignment')

            self.expression()
            self.match('comma')
            self.match('identifier')
            self.match('assignment')
            self.expression()
            self.match('comma')
            self.comparison()
            self.match('close_parenthesis')
            self.match('colon')
            self.match('open_curly_bracket')
            self.new_line()

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')

        elif self.check_token('func'):
            print("STATEMENT --> FUNCTION")
            self.next_token()
            self.match('identifier')
            self.match('open_square_bracket')
            if not self.current_token.kind == 'close_square_bracket':
                self.match('identifier')
            while not self.current_token.kind == 'close_square_bracket':
                    self.match('comma')
                    self.match('identifier')

            self.match('close_square_bracket')
            self.match('colon')
            self.match('open_curly_bracket')
            self.new_line()

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')


        elif self.check_token('identifier') and not self.checkPeek('assignment'):
            print("STATEMENT --> FUNCTION_CALL")

            self.match('identifier')
            self.match('open_parenthesis')
            if not self.current_token.kind == 'close_parenthesis':
                self.match('identifier')
            while not self.current_token.kind == 'close_parenthesis':
                self.match('comma')
                self.match('identifier')

            self.match('close_parenthesis')

        elif self.check_token('identifier'):
            print("STATEMENT --> IDENTIFIER")

            if self.current_token.text not in self.symbols:
                self.symbols.add(self.current_token.text)

            self.match('identifier')
            self.match('assignment')

            self.expression()


        elif self.check_token('end_of_line'):
            self.match('end_of_line')

        else:
            self.abort("Invalid statement at " + self.current_token.text + " (" + self.current_token.kind + ")")

        self.new_line()

    def comparison(self):
        print("STATEMENT --> COMPARISON")

        self.expression()
        if self.comparison_operator():
            print(self.current_token.kind)
            self.next_token()
            self.expression()
        else:
            self.abort("Expected comparison operator at: " + self.current_token.text)

    def expression(self):
        print("STATEMENT --> EXPRESSION")

        self.term()
        while self.check_token('plus') or self.check_token('minus'):
            print(self.current_token.kind)
            self.next_token()
            self.term()

    def term(self):
        print("TERM")

        self.leaf()
        while self.check_token('asterisk') or self.check_token('divide'):
            print(self.current_token.kind)
            self.next_token()
            self.leaf()


    def leaf(self):
        print("leaf -->" + self.current_token.text)

        if self.check_token('integer_number') or self.check_token('decimal_number'):
            print(self.current_token.kind)
            self.next_token()
        elif self.check_token('identifier'):
            print(self.current_token.kind)
            self.next_token()
        else:
            self.abort("Unexpected token at " + self.current_token.text)

    def new_line(self):
        try:


            self.match('end_of_line')
            self.line_counter += 1
            print("STATEMENT --> NEWLINE")
            while self.check_token('end_of_line'):
                self.line_counter += 1
                self.next_token()
        except:
            pass