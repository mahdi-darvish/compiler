import sys


class Lexer:
    def __init__(self, input):
        self.msg = ''
        self.flag = True
        self.input = input + '\n'
        self.current_char = ''
        self.current_pointer = -1
        self.next_character()

    def next_character(self):
        self.current_pointer += 1
        if self.current_pointer >= len(self.input):
            self.current_charv = '\0'
        else:
            self.current_char = self.input[self.current_pointer]

    def peek(self):
        if self.current_pointer + 1 >= len(self.input):
            return '\0'
        return self.input[self.current_pointer + 1]

    def abort(self, message):
        self.flag = False
        self.msg = "Lexing error. " + message

    def skipWhitespace(self):
        while self.current_char == ' ' or self.current_char == '\t' or self.current_char == '\r':
            self.next_character()

    def getToken(self):

        self.skipWhitespace()
        token = None

        if self.input[self.current_pointer:self.current_pointer+10] == 'if_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+10]
            self.current_pointer += 8
            self.next_character()

            token = Token(tokText, 'if')
        elif self.input[self.current_pointer:self.current_pointer+12] == 'else_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+12]
            self.current_pointer += 10
            self.next_character()

            token = Token(tokText, 'else')
        elif self.input[self.current_pointer:self.current_pointer+11] == 'for_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+11]
            self.current_pointer += 9
            self.next_character()

            token = Token(tokText, 'for')
        elif self.input[self.current_pointer:self.current_pointer+13] == 'while_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+13]
            self.current_pointer += 11
            self.next_character()

            token = Token(tokText, 'while')
        elif self.input[self.current_pointer:self.current_pointer+12] == 'func_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+12]
            self.current_pointer += 10
            self.next_character()

            token = Token(tokText, 'func')

        elif self.current_char == '(':
            token = Token(self.current_char, 'open_parenthesis')
        elif self.current_char == ')':
            token = Token(self.current_char, 'close_parenthesis')
        elif self.current_char == '\n':
            token = Token(self.current_char, 'end_of_line')
        elif self.current_char == '\0':
            token = Token('', 'end_of_file')
        elif self.current_char == '[':
            token = Token(self.current_char, 'open_square_bracket')
        elif self.current_char == ']':
            token = Token(self.current_char, 'close_square_bracket')
        elif self.current_char == '{':
            token = Token(self.current_char, 'open_curly_bracket')
        elif self.current_char == '}':
            token = Token(self.current_char, 'close_curly_bracket')
        elif self.current_char == ':':
            token = Token(self.current_char, 'colon')
        elif self.current_char == ',':
            token = Token(self.current_char, 'comma')
        elif self.current_char == '*':
            token = Token(self.current_char, 'asterisk')
        elif self.current_char == '>':
            token = Token(self.current_char, 'greater_than')
        elif self.current_char == '+':
            if self.peek() == '+':
                lastChar = self.current_char
                self.next_character()
                token = Token(lastChar + self.current_char, 'plus')
            else:
                self.abort("Expected ++, got +" + self.peek())
        elif self.current_char == '-':
            if self.peek() == '-':
                lastChar = self.current_char
                self.next_character()
                token = Token(lastChar + self.current_char, 'minus')
            else:
                self.abort("Expected --, got -" + self.peek())
        elif self.current_char == '/':
            if self.peek() == '\\':
                lastChar = self.current_char
                self.next_character()
                token = Token(lastChar + self.current_char, 'divide')

            else:
                self.abort("Expected /\\, got /" + self.peek())
        elif self.current_char == '<':
            if self.peek() == '=':
                lastChar = self.current_char
                self.next_character()
                if self.peek() == '=':
                    lastChar += '=='
                    self.next_character()
                    if self.peek() == '>':
                        self.next_character()
                        token = Token(lastChar + self.current_char, 'equality')
                    else:
                        self.abort("Unknown token: " + lastChar)
                elif self.peek() == '>':
                    lastChar += '='
                    self.next_character()
                    token = Token(lastChar + self.current_char, 'assignment')
                else:
                    self.abort("Unknown token: " + lastChar)
            else:
                token = Token(self.current_char, 'less_than')
        elif self.current_char.isdigit():

            startPos = self.current_pointer
            while self.peek().isdigit():
                self.next_character()
            if self.peek() == '.':
                self.next_character()

                if not self.peek().isdigit():
                    tokText = self.input[startPos: self.current_pointer + 1]
                    token = Token(tokText, 'decimal_number')
                else:
                    while self.peek().isdigit():
                        self.next_character()
                    tokText = self.input[startPos: self.current_pointer + 1]
                    token = Token(tokText, 'decimal_number')
            else:
                tokText = self.input[startPos: self.current_pointer + 1]
                token = Token(tokText, 'integer_number')
        elif self.current_char == '.':
            if self.peek().isdigit():
                startPos = self.current_pointer
                while self.peek().isdigit():
                    self.next_character()

                tokText = self.input[startPos: self.current_pointer + 1]
                token = Token(tokText, 'decimal_number')
            else:
                self.abort("Unknown token: " + self.current_char)
        elif self.current_char.isalpha():
            if self.current_pointer + 8 >= len(self.input):
                self.abort("Unknown token: " + self.input[self.current_pointer:])
            else:
                family_check = self.input[self.current_pointer : self.current_pointer + 8]
                if family_check == 'darvish_':
                    self.current_pointer += 7
                    if self.peek().isalnum():
                        startPos = self.current_pointer
                        while self.peek().isalnum():
                            self.next_character()
                        tokText = 'darvish' + self.input[startPos: self.current_pointer + 1]
                        token = Token(tokText, 'identifier')
                    else:
                        self.abort("Unknown token: " 'darvish'+ self.input[self.current_pointer:])
                else:
                    startpos = self.current_pointer
                    while self.current_char.isalnum() or self.current_char == '_':
                        self.next_character()
                    self.abort("Unknown token: " + self.input[startpos:self.current_pointer])
        else:
            self.abort("Unknown token: " + self.current_char)

        self.next_character()
        return token


class Token:
    def __init__(self, tokenText, tokenKind):
        self.text = tokenText
        self.kind = tokenKind
