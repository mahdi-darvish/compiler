from django.http import HttpResponse
from django.shortcuts import render

def homepage(request):
    input = ''
    error_lexer = ''
    error_syntax  = ''
    answer_lexer  = ''
    answer_syntax  = ''
    if request.method == 'POST':
        input = request.POST.get('numb')
    # input = '''
    #     darvish_123 <=> 1.23 +
    #                         '''
        input += '\0'
        try:
            lexer = Lexer(input)
            tokens = []
            token = lexer.getToken()
            while token.kind != 'end_of_file':
                temp = []
                temp.append(token.kind)
                temp.append(token.text)
                tokens.append(temp)
                token = lexer.getToken()
            answer_lexer = tokens
        except:
            error_lexer = lexer.msg
            return render(request, 'index.html',
                          {'inp': input,'el': error_lexer,  'al': answer_lexer, })

        lexer2 = Lexer(input)
        syntax = Syntax(lexer2)
        try:
            syntax.start()
            answer_syntax = syntax.parsed
        except:
            error_syntax = syntax.msg
    return render(request, 'index.html', {'inp': input, 'el': error_lexer, 'es': error_syntax, 'al': answer_lexer, 'as': answer_syntax})




import sys


class Lexer:
    def __init__(self, input):
        self.msg = ''
        self.input = input + '\n'
        self.current_char = ''
        self.current_pointer = -1
        self.next_character()

    def next_character(self):
        self.current_pointer += 1
        if self.current_pointer >= len(self.input):
            self.current_charv = '\0'
        else:
            self.current_char = self.input[self.current_pointer]

    def peek(self):
        if self.current_pointer + 1 >= len(self.input):
            return '\0'
        return self.input[self.current_pointer + 1]

    def abort(self, message):
        self.msg = "Lexing error. " + message
        sys.exit("Lexing error. " + message)

    def skipWhitespace(self):
        while self.current_char == ' ' or self.current_char == '\t' or self.current_char == '\r':
            self.next_character()

    def getToken(self):

        self.skipWhitespace()
        token = None

        if self.input[self.current_pointer:self.current_pointer+10] == 'if_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+10]
            self.current_pointer += 8
            self.next_character()

            token = Token(tokText, 'if')
        elif self.input[self.current_pointer:self.current_pointer+12] == 'else_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+12]
            self.current_pointer += 10
            self.next_character()

            token = Token(tokText, 'else')
        elif self.input[self.current_pointer:self.current_pointer+11] == 'for_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+11]
            self.current_pointer += 9
            self.next_character()

            token = Token(tokText, 'for')
        elif self.input[self.current_pointer:self.current_pointer+13] == 'while_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+13]
            self.current_pointer += 11
            self.next_character()

            token = Token(tokText, 'while')
        elif self.input[self.current_pointer:self.current_pointer+12] == 'func_darvish':
            tokText = self.input[self.current_pointer:self.current_pointer+12]
            self.current_pointer += 10
            self.next_character()

            token = Token(tokText, 'func')

        elif self.current_char == '(':
            token = Token(self.current_char, 'open_parenthesis')
        elif self.current_char == ')':
            token = Token(self.current_char, 'close_parenthesis')
        elif self.current_char == '\n':
            token = Token(self.current_char, 'end_of_line')
        elif self.current_char == '\0':
            token = Token('', 'end_of_file')
        elif self.current_char == '[':
            token = Token(self.current_char, 'open_square_bracket')
        elif self.current_char == ']':
            token = Token(self.current_char, 'close_square_bracket')
        elif self.current_char == '{':
            token = Token(self.current_char, 'open_curly_bracket')
        elif self.current_char == '}':
            token = Token(self.current_char, 'close_curly_bracket')
        elif self.current_char == ':':
            token = Token(self.current_char, 'colon')
        elif self.current_char == ',':
            token = Token(self.current_char, 'comma')
        elif self.current_char == '*':
            token = Token(self.current_char, 'asterisk')
        elif self.current_char == '>':
            token = Token(self.current_char, 'greater_than')
        elif self.current_char == '+':
            if self.peek() == '+':
                lastChar = self.current_char
                self.next_character()
                token = Token(lastChar + self.current_char, 'plus')
            else:
                self.abort("Expected ++, got +" + self.peek())
        elif self.current_char == '-':
            if self.peek() == '-':
                lastChar = self.current_char
                self.next_character()
                token = Token(lastChar + self.current_char, 'minus')
            else:
                self.abort("Expected --, got -" + self.peek())
        elif self.current_char == '/':
            if self.peek() == '\\':
                lastChar = self.current_char
                self.next_character()
                token = Token(lastChar + self.current_char, 'divide')

            else:
                self.abort("Expected /\\, got /" + self.peek())
        elif self.current_char == '<':
            if self.peek() == '=':
                lastChar = self.current_char
                self.next_character()
                if self.peek() == '=':
                    lastChar += '=='
                    self.next_character()
                    if self.peek() == '>':
                        self.next_character()
                        token = Token(lastChar + self.current_char, 'equality')
                    else:
                        self.abort("Unknown token: " + lastChar)
                elif self.peek() == '>':
                    lastChar += '='
                    self.next_character()
                    token = Token(lastChar + self.current_char, 'assignment')
                else:
                    self.abort("Unknown token: " + lastChar)
            else:
                token = Token(self.current_char, 'less_than')
        elif self.current_char.isdigit():

            startPos = self.current_pointer
            while self.peek().isdigit():
                self.next_character()
            if self.peek() == '.':
                self.next_character()

                if not self.peek().isdigit():
                    tokText = self.input[startPos: self.current_pointer + 1]
                    token = Token(tokText, 'decimal_number')
                else:
                    while self.peek().isdigit():
                        self.next_character()
                    tokText = self.input[startPos: self.current_pointer + 1]
                    token = Token(tokText, 'decimal_number')
            else:
                tokText = self.input[startPos: self.current_pointer + 1]
                token = Token(tokText, 'integer_number')
        elif self.current_char == '.':
            if self.peek().isdigit():
                startPos = self.current_pointer
                while self.peek().isdigit():
                    self.next_character()

                tokText = self.input[startPos: self.current_pointer + 1]
                token = Token(tokText, 'decimal_number')
            else:
                self.abort("Unknown token: " + self.current_char)
        elif self.current_char.isalpha():
            if self.current_pointer + 8 >= len(self.input):
                self.abort("Unknown token: " + self.input[self.current_pointer:])
            else:
                family_check = self.input[self.current_pointer : self.current_pointer + 8]
                if family_check == 'darvish_':
                    self.current_pointer += 7
                    if self.peek().isalnum():
                        startPos = self.current_pointer
                        while self.peek().isalnum():
                            self.next_character()
                        tokText = 'darvish' + self.input[startPos: self.current_pointer + 1]
                        token = Token(tokText, 'identifier')
                    else:
                        self.abort("Unknown token: " 'darvish'+ self.input[self.current_pointer:])
                else:
                    startpos = self.current_pointer
                    while self.current_char.isalnum() or self.current_char == '_':
                        self.next_character()
                    self.abort("Unknown token: " + self.input[startpos:self.current_pointer])
        else:
            self.abort("Unknown token: " + self.current_char)

        self.next_character()
        return token


class Token:
    def __init__(self, tokenText, tokenKind):
        self.text = tokenText
        self.kind = tokenKind



import sys


class Syntax:
    def __init__(self, lexical_analyser):
        self.parsed = []
        self.lexical_analyser = lexical_analyser
        self.msg = ''
        self.symbols = set()
        self.labels = set()
        self.current_token = None
        self.peekToken = None
        self.next_token()
        self.next_token()
        self.line_counter = 1

    def check_token(self, kind):
        return kind == self.current_token.kind

    def checkPeek(self, kind):
        return kind == self.peekToken.kind

    def match(self, kind):
        if not self.check_token(kind):
            self.abort("Expected " + kind + ", got " + self.current_token.kind)
        self.parsed.append('matched: {}'.format(kind))
        self.next_token()

    def next_token(self):
        self.current_token = self.peekToken
        self.peekToken = self.lexical_analyser.getToken()

    def comparison_operator(self):
        return self.check_token('greater_than') or \
               self.check_token('equality') or \
               self.check_token('less_than')


    def abort(self, message):
        self.msg = "Error at line {}. ".format(self.line_counter) + message
        sys.exit("Error at line {}. ".format(self.line_counter) + message)


    def start(self):
        self.parsed.append("start")

        self.new_line()

        while not self.check_token('end_of_file'):
            self.statement()

    def statement(self):

        if self.check_token('if'):
            self.parsed.append("STATEMENT --> IF")
            self.next_token()
            self.match('open_parenthesis')
            self.comparison()

            self.match('close_parenthesis')
            self.match('colon')
            self.match('open_curly_bracket')

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')

        elif self.check_token('else'):
            self.parsed.append("STATEMENT --> ELSE")
            self.next_token()
            self.match('colon')
            self.match('open_curly_bracket')

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')


        elif self.check_token('while'):
            self.parsed.append("STATEMENT --> WHILE")
            self.next_token()
            self.match('open_parenthesis')
            self.comparison()

            self.match('close_parenthesis')
            self.match('colon')
            self.match('open_curly_bracket')
            self.new_line()

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')


        elif self.check_token('for'):
            self.parsed.append("STATEMENT --> FOR")
            self.next_token()
            self.match('open_parenthesis')
            self.match('identifier')
            self.match('assignment')

            self.expression()
            self.match('comma')
            self.match('identifier')
            self.match('assignment')
            self.expression()
            self.match('comma')
            self.comparison()
            self.match('close_parenthesis')
            self.match('colon')
            self.match('open_curly_bracket')
            self.new_line()

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')

        elif self.check_token('func'):
            self.parsed.append("STATEMENT --> FUNCTION")
            self.next_token()
            self.match('identifier')
            self.match('open_square_bracket')
            if not self.current_token.kind == 'close_square_bracket':
                self.match('identifier')
            while not self.current_token.kind == 'close_square_bracket':
                    self.match('comma')
                    self.match('identifier')

            self.match('close_square_bracket')
            self.match('colon')
            self.match('open_curly_bracket')
            self.new_line()

            while not self.check_token('close_curly_bracket'):
                self.statement()

            self.match('close_curly_bracket')


        elif self.check_token('identifier') and not self.checkPeek('assignment'):
            self.parsed.append("STATEMENT --> FUNCTION_CALL")

            self.match('identifier')
            self.match('open_parenthesis')
            if not self.current_token.kind == 'close_parenthesis':
                self.match('identifier')
            while not self.current_token.kind == 'close_parenthesis':
                self.match('comma')
                self.match('identifier')

            self.match('close_parenthesis')
        elif (self.check_token('identifier') or self.check_token('decimal_number') or self.check_token('integer_number')
                ) and ( self.checkPeek('plus') or self.checkPeek('minus') or
                        self.checkPeek('asterisk') or self.checkPeek('divide')):
                self.expression()

        elif self.check_token('identifier'):
            self.parsed.append("STATEMENT --> IDENTIFIER")

            if self.current_token.text not in self.symbols:
                self.symbols.add(self.current_token.text)

            self.match('identifier')
            self.match('assignment')

            self.expression()


        elif self.check_token('end_of_line'):
            self.match('end_of_line')

        else:
            self.abort("Invalid statement at " + self.current_token.text + " (" + self.current_token.kind + ")")

        self.new_line()

    def comparison(self):
        self.parsed.append("STATEMENT --> COMPARISON")

        self.expression()
        if self.comparison_operator():
            self.parsed.append(self.current_token.kind)
            self.next_token()
            self.expression()
        else:
            self.abort("Expected comparison operator at: " + self.current_token.text)

    def expression(self):
        self.parsed.append("STATEMENT --> EXPRESSION")

        self.term()
        while self.check_token('plus') or self.check_token('minus'):
            self.parsed.append(self.current_token.kind)
            self.next_token()
            self.term()

    def term(self):
        self.parsed.append("TERM")

        self.leaf()
        while self.check_token('asterisk') or self.check_token('divide'):
            self.parsed.append(self.current_token.kind)
            self.next_token()
            self.leaf()


    def leaf(self):
        self.parsed.append("LEAF --> " + self.current_token.text)

        if self.check_token('integer_number') or self.check_token('decimal_number'):
            self.parsed.append(self.current_token.kind)
            self.next_token()
        elif self.check_token('identifier'):
            self.parsed.append(self.current_token.kind)
            self.next_token()
        else:
            self.abort("Unexpected token at " + self.current_token.kind)

    def new_line(self):
        try:


            self.match('end_of_line')
            self.line_counter += 1
            self.parsed.append("STATEMENT --> NEWLINE")
            while self.check_token('end_of_line'):
                self.line_counter += 1
                self.next_token()
        except:
            pass