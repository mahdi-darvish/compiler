from django.http import HttpResponse
from django.shortcuts import render
from .lexical_analyser import Lexer
from .syntax_analyser import Syntax

def homepage(request):
    answer_1 = ''
    answer_2 = ''
    if request.method == 'POST':
        input = request.POST.get('numb')
    # input = '''
    #     if_darvish()
    #                         '''
        input += '\0'
    x, y = main(input)
    print(x)
    print(y)
    x, y = main2(input)
    print(x)
    print(y)
    return render(request, 'index.html', {'answer_1': answer_1, 'asnwer_2': answer_2})

def main(input):

    lexer = Lexer(input)
    syntax = Syntax(lexer)
    syntax.start()
    print(syntax.parsed, syntax.msg)
    return syntax.parsed, syntax.msg

def main2(input):
    lexer = Lexer(input)
    tokens = []
    token = lexer.getToken()
    if lexer.flag:
        while token.kind != 'end_of_file' and lexer.flag:
            temp = []
            temp.append(token.kind)
            temp.append(token.text)
            tokens.append(temp)
            token = lexer.getToken()
    return tokens, lexer.msg